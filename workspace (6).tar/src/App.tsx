import { useState, useEffect } from 'react';

interface Holding {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change: number;
}

interface Coin {
  symbol: string;
  price: string;
  reason: string;
  buyUrl: string;
}

function App() {
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [totalValue, setTotalValue] = useState(17355.00);
  const [portfolioChange, setPortfolioChange] = useState(3.85);
  const [changeValue, setChangeValue] = useState(645.50);

  const researchedCoins: Coin[] = [
    {
      symbol: 'PEPE',
      price: '$0.000012',
      reason: 'Whale accumulation detected. AI sentiment score: 92/100.',
      buyUrl: 'https://app.uniswap.org/#/swap?outputCurrency=0x6982508145454Ce325dDbE47a25d4ec3d2311933'
    },
    {
      symbol: 'WIF',
      price: '$2.45',
      reason: 'Breaking out of consolidation. TG bot volume spike.',
      buyUrl: 'https://jup.ag/swap/SOL-So11111111111111111111111111111111111111112'
    },
    {
      symbol: 'RNDR',
      price: '$7.80',
      reason: 'AI narrative trending. Strong support level holding.',
      buyUrl: 'https://app.uniswap.org/#/swap?outputCurrency=0x6de037ef9ad2725eb40118bb1702ebb27e4aeb24'
    }
  ];

  const holdings: Holding[] = [
    { symbol: 'ETH', name: 'Ethereum', amount: 2.45, value: 10106.25, change: 5.2 },
    { symbol: 'SOL', name: 'Solana', amount: 45.2, value: 6780.00, change: -1.5 }
  ];

  const agents = [
    { name: 'Whale Alert Bot', status: 'Active - Tracking $1M+ moves' },
    { name: 'AI Market Analyzer', status: 'Active - Scanning 50+ pairs' },
    { name: 'Sniper Bot Tracker', status: 'Active - 3 new tokens detected' },
    { name: 'TG Signal Groups', status: 'Active - 12 groups connected' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      const change = (Math.random() - 0.5) * 50;
      setTotalValue(prev => prev + change);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const connectWallet = async () => {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      try {
        const accounts = await (window as any).ethereum.request({ method: 'eth_requestAccounts' });
        const account = accounts[0];
        setWalletAddress(account);
        setWalletConnected(true);

        (window as any).ethereum.on('accountsChanged', (accounts: string[]) => {
          if (accounts.length === 0) {
            setWalletConnected(false);
            setWalletAddress('');
          } else {
            setWalletAddress(accounts[0]);
          }
        });
      } catch (error) {
        console.error("User rejected connection");
      }
    } else {
      alert("MetaMask is not installed! Please install it to connect your wallet.");
      window.open('https://metamask.io/download/', '_blank');
    }
  };

  const formatAddress = (addr: string) => {
    return addr.substring(0, 6) + '...' + addr.substring(38);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8 pb-5 border-b border-white/10">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
            🌊 Sea Chef Labs
          </h1>
          <button
            onClick={connectWallet}
            className={`px-5 py-2.5 rounded-lg font-semibold transition-all ${
              walletConnected
                ? 'bg-green-400 text-slate-900 border border-green-400'
                : 'bg-white/10 text-cyan-400 border border-cyan-400 hover:bg-cyan-400 hover:text-slate-900'
            }`}
          >
            {walletConnected ? formatAddress(walletAddress) : 'Connect Wallet'}
          </button>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">Total Portfolio Value</div>
            <div className="text-3xl font-bold">${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <div className={`text-lg mt-1 ${portfolioChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {portfolioChange >= 0 ? '+' : ''}{portfolioChange.toFixed(2)}% (+${changeValue.toFixed(2)})
            </div>
          </div>
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">24h Profit/Loss</div>
            <div className="text-3xl font-bold text-green-400">+${changeValue.toFixed(2)}</div>
            <div className="text-slate-400 mt-1">Across all chains</div>
          </div>
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">Cash Balance</div>
            <div className="text-3xl font-bold">$2,100.00</div>
            <div className="text-slate-400 mt-1">Ready to deploy</div>
          </div>
        </div>

        {/* Researched Coins */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🎯 Researched Coins to Buy</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {researchedCoins.map((coin, idx) => (
              <div key={idx} className="bg-cyan-500/5 border border-cyan-500/20 rounded-xl p-5 flex flex-col">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-xl">{coin.symbol}</span>
                  <span className="text-slate-400 text-sm">{coin.price}</span>
                </div>
                <div className="text-slate-300 text-sm mb-4 flex-grow">{coin.reason}</div>
                <a
                  href={coin.buyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-cyan-400 to-green-400 text-slate-900 font-bold py-2.5 rounded-md text-center hover:opacity-90 transition-opacity"
                >
                  Buy on {coin.buyUrl.includes('jup.ag') ? 'Jupiter' : 'Uniswap'}
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* Holdings */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🪙 Your Token Holdings</h2>
          <div className="bg-white/3 rounded-xl p-5">
            {holdings.map((holding, idx) => (
              <div key={idx} className={`flex justify-between items-center py-4 ${idx < holdings.length - 1 ? 'border-b border-white/5' : ''}`}>
                <div className="flex items-center gap-4">
                  <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center font-bold text-sm">
                    {holding.symbol}
                  </div>
                  <div>
                    <div className="font-semibold">{holding.name}</div>
                    <div className="text-slate-400 text-sm">{holding.amount} {holding.symbol}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">${holding.value.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                  <div className={holding.change >= 0 ? 'text-green-400' : 'text-red-400'}>
                    {holding.change >= 0 ? '+' : ''}{holding.change}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Agents */}
        <div>
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🤖 Whale AI Agents & TG Bots</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.map((agent, idx) => (
              <div key={idx} className="bg-white/5 p-4 rounded-lg border-l-4 border-green-400">
                <div className="font-semibold mb-1">{agent.name}</div>
                <div className="text-green-400 text-sm">● {agent.status}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
