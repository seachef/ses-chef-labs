import { useState, useEffect } from 'react';

interface Holding {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change: number;
}

interface Coin {
  symbol: string;
  name: string;
  price: string;
  reason: string;
  buyUrl: string;
  score: number;
}

interface WatchedWallet {
  address: string;
  label: string;
}

interface Agent {
  name: string;
  status: string;
  details: {
    label: string;
    value: string;
  }[];
}

function App() {
  const [totalValue, setTotalValue] = useState(17355.00);
  const [portfolioChange] = useState(3.85);
  const [changeValue] = useState(645.50);
  const [watchedWallets, setWatchedWallets] = useState<WatchedWallet[]>([]);
  const [newWalletAddress, setNewWalletAddress] = useState('');
  const [expandedAgent, setExpandedAgent] = useState<number | null>(null);

  const topPicks: Coin[] = [
    {
      symbol: 'PEPE',
      name: 'Pepe',
      price: '$0.000012',
      reason: 'Whale accumulation detected. 3 large wallets buying in last 24h. TG bot volume spike +45%.',
      buyUrl: 'https://app.uniswap.org/#/swap?outputCurrency=0x6982508145454Ce325dDbE47a25d4ec3d2311933',
      score: 92
    },
    {
      symbol: 'WIF',
      name: 'dogwifhat',
      price: '$2.45',
      reason: 'Breaking out of consolidation. Jupiter aggregator volume up 120%. Strong Solana momentum.',
      buyUrl: 'https://jup.ag/swap/SOL-So11111111111111111111111111111111111111112',
      score: 88
    },
    {
      symbol: 'RNDR',
      name: 'Render Network',
      price: '$7.80',
      reason: 'AI narrative trending. GPU compute demand rising. Strong support at $7.20 holding firm.',
      buyUrl: 'https://app.uniswap.org/#/swap?outputCurrency=0x6de037ef9ad2725eb40118bb1702ebb27e4aeb24',
      score: 85
    },
    {
      symbol: 'ARB',
      name: 'Arbitrum',
      price: '$1.25',
      reason: 'Layer 2 momentum building. Whale buys increasing 3x this week. TVL hitting new highs.',
      buyUrl: 'https://app.uniswap.org/#/swap?outputCurrency=0x912CE59144191C1204E64559FE8253a0e49E6548',
      score: 81
    }
  ];

  const moreResearchedCoins: Coin[] = [
    {
      symbol: 'HYPE',
      name: 'Hyperliquid',
      price: '$42.18',
      reason: 'Perp DEX leader. $432B monthly volume. New chain launch imminent.',
      buyUrl: 'https://app.uniswap.org',
      score: 79
    },
    {
      symbol: 'MON',
      name: 'Monad',
      price: '$3.45',
      reason: '10k TPS EVM L1. $494M raised. Testnet live, mainnet soon.',
      buyUrl: 'https://app.uniswap.org',
      score: 76
    },
    {
      symbol: 'ONDO',
      name: 'Ondo Finance',
      price: '$1.23',
      reason: 'RWA leader. Institutional adoption growing. TVL up 340% this quarter.',
      buyUrl: 'https://app.uniswap.org',
      score: 74
    },
    {
      symbol: 'VIRTUAL',
      name: 'Virtuals Protocol',
      price: '$2.34',
      reason: 'AI agent token leader. 24.5% pump in 24h. Strong community momentum.',
      buyUrl: 'https://app.uniswap.org',
      score: 72
    },
    {
      symbol: 'TAO',
      name: 'Bittensor',
      price: '$512.33',
      reason: 'Decentralized AI network. Subnet activity surging. AI narrative strong.',
      buyUrl: 'https://app.uniswap.org',
      score: 69
    },
    {
      symbol: 'SUI',
      name: 'Sui',
      price: '$4.67',
      reason: 'Move-based L1. 15.2% 24h gain. DeFi TVL breaking records.',
      buyUrl: 'https://app.uniswap.org',
      score: 67
    },
    {
      symbol: 'BERA',
      name: 'Berachain',
      price: '$5.67',
      reason: 'Proof of Liquidity consensus. Unique tokenomics. Early stage opportunity.',
      buyUrl: 'https://app.uniswap.org',
      score: 65
    },
    {
      symbol: 'FET',
      name: 'Fetch.ai',
      price: '$1.23',
      reason: 'AI + DeFi convergence. Autonomous agents gaining traction. 11.2% 24h.',
      buyUrl: 'https://app.uniswap.org',
      score: 63
    }
  ];

  const holdings: Holding[] = [
    { symbol: 'ETH', name: 'Ethereum', amount: 2.45, value: 10106.25, change: 5.2 },
    { symbol: 'SOL', name: 'Solana', amount: 45.2, value: 6780.00, change: -1.5 }
  ];

  const agents: Agent[] = [
    {
      name: 'Whale Alert Bot',
      status: 'Active - Tracking $1M+ moves',
      details: [
        { label: 'Last 24h Alerts', value: '47 whale movements detected' },
        { label: 'Largest Move', value: '$12.4M PEPE transferred to Binance' },
        { label: 'Accumulation Pattern', value: '3 wallets accumulating WIF over 48h' },
        { label: 'Chains Monitored', value: 'ETH, SOL, ARB, BASE, BSC' },
        { label: 'Success Rate', value: '78% of tracked whales profitable this month' }
      ]
    },
    {
      name: 'AI Market Analyzer',
      status: 'Active - Scanning 50+ pairs',
      details: [
        { label: 'Current Analysis', value: 'Scanning momentum, volume, sentiment across 50+ pairs' },
        { label: 'Top Signal', value: 'PEPE - Strong buy signal (92/100 confidence)' },
        { label: 'Data Sources', value: '61 DEX + CEX sources, 26 chains' },
        { label: 'Update Frequency', value: 'Every 30 seconds' },
        { label: 'Model Accuracy', value: '84% prediction accuracy (30-day backtest)' }
      ]
    },
    {
      name: 'Sniper Bot Tracker',
      status: 'Active - 3 new tokens detected',
      details: [
        { label: 'New Detections (24h)', value: '3 tokens with sniper activity' },
        { label: 'Token #1', value: 'Unknown meme - 12 snipers in first block' },
        { label: 'Token #2', value: 'AI agent token - 8 snipers, liquidity locked' },
        { label: 'Token #3', value: 'DePIN project - 5 snipers, team doxxed' },
        { label: 'Risk Assessment', value: 'Token #2 looks safest - liquidity locked 6 months' }
      ]
    },
    {
      name: 'TG Signal Groups',
      status: 'Active - 12 groups connected',
      details: [
        { label: 'Active Groups', value: '12 Telegram signal groups monitored' },
        { label: 'Consensus Signal', value: '8/12 groups calling PEPE accumulation' },
        { label: 'Top Mentioned', value: 'PEPE (8 groups), WIF (6 groups), RNDR (5 groups)' },
        { label: 'Bot Speed', value: '4-8ms execution via Banana Gun / Maestro' },
        { label: 'Signal Accuracy', value: '72% of group signals profitable within 24h' }
      ]
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      const change = (Math.random() - 0.5) * 50;
      setTotalValue(prev => prev + change);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const addWatchedWallet = () => {
    if (!newWalletAddress.trim()) {
      alert('Please enter a wallet address');
      return;
    }
    setWatchedWallets([...watchedWallets, {
      address: newWalletAddress,
      label: `Wallet ${watchedWallets.length + 1}`
    }]);
    setNewWalletAddress('');
  };

  const removeWatchedWallet = (index: number) => {
    setWatchedWallets(watchedWallets.filter((_, i) => i !== index));
  };

  const formatAddress = (addr: string) => {
    return addr.substring(0, 8) + '...' + addr.substring(addr.length - 6);
  };

  const toggleAgent = (index: number) => {
    setExpandedAgent(expandedAgent === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8 pb-5 border-b border-white/10">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
            Sea Chef Labs
          </h1>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={newWalletAddress}
              onChange={(e) => setNewWalletAddress(e.target.value)}
              placeholder="Enter wallet address to watch"
              className="bg-white/5 border border-white/20 text-white px-3 py-2 rounded-md w-64"
            />
            <button
              onClick={addWatchedWallet}
              className="bg-white/10 border border-cyan-400 text-cyan-400 px-5 py-2 rounded-lg font-semibold hover:bg-cyan-400 hover:text-slate-900 transition-all"
            >
              + Watch Wallet
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">Total Portfolio Value</div>
            <div className="text-3xl font-bold">
              ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className={`text-lg mt-1 ${portfolioChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {portfolioChange >= 0 ? '+' : ''}{portfolioChange.toFixed(2)}% (+${changeValue.toFixed(2)})
            </div>
          </div>
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">24h Profit/Loss</div>
            <div className="text-3xl font-bold text-green-400">+${changeValue.toFixed(2)}</div>
            <div className="text-slate-400 mt-1">Across all chains</div>
          </div>
          <div className="bg-white/5 rounded-xl p-5 border border-white/5">
            <div className="text-slate-400 text-sm mb-2">Total Tokens</div>
            <div className="text-3xl font-bold">5</div>
            <div className="text-slate-400 mt-1">3 profitable today</div>
          </div>
        </div>

        {/* Top 4 AI Picks */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🎯 AI Top Picks - Researched & Ready</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {topPicks.map((coin, idx) => (
              <div key={idx} className="bg-cyan-500/5 border border-cyan-500/20 rounded-xl p-5 flex flex-col">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-xl text-cyan-400">{coin.symbol}</span>
                  <span className="text-slate-400 text-sm">{coin.price}</span>
                </div>
                <div className="inline-block bg-green-400/10 border border-green-400/30 text-green-400 px-2 py-1 rounded text-xs font-semibold mb-2 w-fit">
                  AI Score: {coin.score}/100
                </div>
                <div className="text-slate-300 text-sm mb-4 flex-grow">{coin.reason}</div>
                <a
                  href={coin.buyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-cyan-400 to-green-400 text-slate-900 font-bold py-2.5 rounded-md text-center hover:opacity-90 transition-opacity"
                >
                  Buy on {coin.buyUrl.includes('jup.ag') ? 'Jupiter' : 'Uniswap'}
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* More Researched Coins */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🔬 More Researched Coins</h2>
          <div className="bg-white/3 rounded-xl p-5">
            {moreResearchedCoins.map((coin, idx) => (
              <div key={idx} className="flex justify-between items-center py-3 border-b border-white/5 last:border-b-0 hover:bg-white/3 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 flex items-center justify-center font-bold text-xs text-cyan-400">
                    {coin.symbol.substring(0, 4)}
                  </div>
                  <div>
                    <div className="font-semibold">{coin.name}</div>
                    <div className="text-slate-400 text-xs">{coin.reason}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-semibold">{coin.price}</span>
                  <span className="bg-green-400/10 border border-green-400/30 text-green-400 px-2 py-1 rounded text-xs font-semibold">
                    {coin.score}/100
                  </span>
                  <a
                    href={coin.buyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 px-3 py-1.5 rounded-md text-xs font-semibold hover:bg-cyan-500/20 transition-colors"
                  >
                    Buy
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Watched Wallets */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">👁️ Watched Wallets</h2>
          <div className="bg-white/3 rounded-xl p-5">
            {watchedWallets.length === 0 ? (
              <div className="text-center py-10 text-slate-400">
                <p>Add wallet addresses above to watch their activity and holdings</p>
              </div>
            ) : (
              watchedWallets.map((wallet, idx) => (
                <div key={idx} className="flex justify-between items-center py-3 border-b border-white/5 last:border-b-0">
                  <div>
                    <div className="text-slate-400 text-xs">{wallet.label}</div>
                    <div className="font-mono text-sm text-cyan-400">{formatAddress(wallet.address)}</div>
                  </div>
                  <button
                    onClick={() => removeWatchedWallet(idx)}
                    className="bg-red-500/10 border border-red-500/30 text-red-400 px-3 py-1 rounded text-xs hover:bg-red-500/20 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Holdings */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🪙 Your Token Holdings</h2>
          <div className="bg-white/3 rounded-xl p-5">
            {holdings.map((holding, idx) => (
              <div key={idx} className={`flex justify-between items-center py-4 ${idx < holdings.length - 1 ? 'border-b border-white/5' : ''}`}>
                <div className="flex items-center gap-4">
                  <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center font-bold text-sm">
                    {holding.symbol}
                  </div>
                  <div>
                    <div className="font-semibold">{holding.name}</div>
                    <div className="text-slate-400 text-sm">{holding.amount} {holding.symbol}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">${holding.value.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                  <div className={holding.change >= 0 ? 'text-green-400' : 'text-red-400'}>
                    {holding.change >= 0 ? '+' : ''}{holding.change}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Agents - Expandable */}
        <div>
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🤖 Whale AI Agents & TG Bots</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.map((agent, idx) => (
              <div
                key={idx}
                className={`bg-white/5 p-4 rounded-lg border-l-4 cursor-pointer transition-all ${
                  expandedAgent === idx ? 'border-l-cyan-400 bg-white/8' : 'border-l-green-400 hover:bg-white/8'
                }`}
                onClick={() => toggleAgent(idx)}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-semibold mb-1">{agent.name}</div>
                    <div className="text-green-400 text-sm">● {agent.status}</div>
                  </div>
                  <div className={`text-slate-400 text-sm transition-transform ${expandedAgent === idx ? 'rotate-180' : ''}`}>
                    ▼
                  </div>
                </div>
                {expandedAgent === idx && (
                  <div className="mt-4 space-y-3">
                    {agent.details.map((detail, detailIdx) => (
                      <div key={detailIdx} className="pb-2 border-b border-white/5 last:border-b-0">
                        <div className="text-slate-400 text-xs mb-1">{detail.label}</div>
                        <div className="text-white font-medium text-sm">{detail.value}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
